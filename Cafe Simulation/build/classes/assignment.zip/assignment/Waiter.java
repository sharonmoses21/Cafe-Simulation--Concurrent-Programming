/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author vazeer
 */
public class Waiter implements Runnable {
    String name;
    Cafe cf;
    public boolean closingTime = false;
    
    public Waiter(String position,Cafe c)
    {
        this.name = position;
        this.cf = c;
    }

    public void run()
    {
        try {
            Thread.sleep(1000);

        } catch (InterruptedException ex) {
            Logger.getLogger(Waiter.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println("WAITER STARTED.....");
        while(!closingTime){
            try {
                cf.Serve(name);
            } catch (InterruptedException ex) {
                Logger.getLogger(Owner.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        if(closingTime){
            try {
                Thread.sleep(5000);
            } catch (InterruptedException ex) {
                Logger.getLogger(Owner.class.getName()).log(Level.SEVERE, null, ex);
            } 
        }

    }
}
