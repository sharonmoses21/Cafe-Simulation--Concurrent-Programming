/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment;

import java.util.Date;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author jared
 */
public class Customer implements Runnable{
    int order; String name; Date inTime; 
    Cafe cf; 
    
    public Customer (Cafe c){
        this.cf = c;
    }
    
    public String getName(){
        return name;
    }
    
    public Date getInTime(){
        return inTime;
    }
    
    public void setName (String name) {
        this.name = name;
    }
    
    void setInTime(Date inTime) {
        this.inTime = inTime;
    }

    public void run() {
        try {
            goCafe();
        } catch (InterruptedException ex) {
            Logger.getLogger(Customer.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public synchronized void goCafe() throws InterruptedException{
        cf.enter(this);
    }
}
