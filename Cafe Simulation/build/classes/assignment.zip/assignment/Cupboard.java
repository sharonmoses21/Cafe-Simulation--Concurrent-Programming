/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment;

/**
 *
 * @author jared
 */
public class Cupboard{
    
    ServingArea sa;
    
    public Cupboard(){
        
    }
    
    //function for taking cup
    public void takeCup(String position) throws InterruptedException{
        System.out.println(position + " TAKING CUP FROM CUPBOARD");
    }
    
    public void takeGlass(String position) throws InterruptedException{
        System.out.println(position + " TAKING GLASS FROM CUPBOARD");
    }
    
    public void takeMilk(String position) throws InterruptedException{
        System.out.println(position + " TAKING MILK FROM CUPBOARD");
    }
    
    public void takeCoffee(String position) throws InterruptedException{
        System.out.println(position + " TAKING COFFEE FROM CUPBOARD");
    }


}
