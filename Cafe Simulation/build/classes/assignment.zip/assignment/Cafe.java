/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment;

import java.util.LinkedList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author jared
 */
public class Cafe {
    ServingArea S;
    int order; int seatNum = 10;
    String orderName;
    boolean checkServed; //checking whether customer had made an order
    static Semaphore semaphore = new Semaphore (10); //maximum 10 customers
    Customer cus; Owner ow; Waiter wa;
    
    List<Customer> listCustomer;
    
    public Cafe(ServingArea se){
        this.S = se;
        listCustomer = new LinkedList<Customer>();
    }
    

    public void makeJuice(String position, int order) throws InterruptedException{
        S.useCupboard(position, order);
        S.useJuiceTap(position);
        System.out.println(position + " IS NOW MAKING FRUIT JUICE");
        System.out.println(position + " HAVE FINISHED MAKING FRUIT JUICE");
    }
    
    public void makeCappucino(String position, int order) throws InterruptedException{
        S.useCupboard(position, order);
        System.out.println(position + " IS NOW MAKING CAPPUCINO");
        System.out.println(position + " HAVE FINISHED MAKING CAPPUCINO");
    }
    
    public void enter(Customer customer) throws InterruptedException{
        synchronized (listCustomer){
            if (listCustomer.size() == seatNum){
                System.out.println("CURRENTLY THERE'S NO SEAT AVAILABLE");
            }
        
            ((LinkedList<Customer>) listCustomer).offer(customer);
            System.out.println("CUSTOMER " + customer.getName() + "ENTERED THE CAFE");
            if(listCustomer.size() == 1){
                listCustomer.notify();
            }
        }
    }
    
    synchronized public void makeOrder(String position,Customer customer) {
        order = new Random().nextInt(2); //generate 0 or 1
        if (order == 0) {
            System.out.println("CUSTOMER " + customer.getName() + " HAD ORDERED FRUIT JUICE");
            try {
                makeJuice(position,order);
            } catch (InterruptedException ex) {
                Logger.getLogger(Cafe.class.getName()).log(Level.SEVERE, null, ex);
            }
            this.orderName = "FRUIT JUICE";
            return;
        } else {
            System.out.println("CUSTOMER " + customer.getName() + " HAD ORDERED CAPPUCINO");
            try {
                makeCappucino(position,order);
            } catch (InterruptedException ex) {
                Logger.getLogger(Cafe.class.getName()).log(Level.SEVERE, null, ex);
            }
            this.orderName = "CAPPUCINO";
            return;
        }
    }
    
    public void Serve(String position) throws InterruptedException {
        Customer customer;
        synchronized (listCustomer){

            while (listCustomer.size() == 0) {
                System.out.println(position + " IS NOW WAITING FOR CUSTOMER");
                listCustomer.wait();
            }
            
            customer = (Customer) ((LinkedList<?>) listCustomer).poll();
            System.out.println(position + " NOW SERVING CUSTOMER " + customer.getName());
            takeOrder(position,customer);
            long duration = 0;
            System.out.println("CUSTOMER " +customer.getName() + "IS NOW DRINKING " + orderName);
            
        }

    }
    
    public void takeOrder(String position, Customer customer){
        System.out.println(position + "IS NOW TAKING ORDER");
        makeOrder(position,customer);
        try {
            Thread.sleep(2000);
        } catch (InterruptedException ex) {
            Logger.getLogger(Cafe.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
