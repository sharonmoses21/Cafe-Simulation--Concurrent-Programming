/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment;

/**
 *
 * @author vazeer
 */
public class MainClass {
    public static void main(String ar[])
    {
        Cupboard c = new Cupboard();
        ServingArea s = new ServingArea(c);
        Cafe cafe = new Cafe(s);
        Owner own = new Owner("OWNER",cafe);
        Waiter wait = new Waiter("WAITER",cafe);
        CustomerGenerator cg = new CustomerGenerator(cafe);
        
        Thread thown = new Thread(own);
        Thread thwait = new Thread(wait);
        Thread thcus = new Thread(cg);
        
        thcus.start();
        thown.start();
        thwait.start();
    }
}

