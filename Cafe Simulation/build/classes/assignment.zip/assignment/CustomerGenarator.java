/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package assignment;

/**
 *
 * @author jared
 */
import java.util.Date;
import java.util.concurrent.TimeUnit;

class CustomerGenerator implements Runnable
{
    Cafe cafe;
    public boolean closingTime = false;
    public CustomerGenerator(Cafe c)
    {
        this.cafe = c;
    }
 
    public void run()
    {
        while(!closingTime)
        {
            Customer customer = new Customer(cafe);
            customer.setInTime(new Date());
            Thread thcustomer = new Thread(customer);
            customer.setName("CUSTOMER "+thcustomer.getId());
            thcustomer.start();
 
            try
            {
               TimeUnit.SECONDS.sleep((long)(Math.random()*10));
            }
            catch(InterruptedException iex)
            {
                iex.printStackTrace();
            }
        }
        if (closingTime) { try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} return;}
    }
    
    public synchronized void setclosingTime()
    { 
        closingTime = true;
            System.out.println("Closing? Ok.");
    }
}
