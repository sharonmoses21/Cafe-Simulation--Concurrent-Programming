/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment;

/**
 *
 * @author jared
 */
public class Clock implements Runnable{
    private CustomerGenerator cu; private Owner ow; private Waiter wa;
    
    public Clock(CustomerGenerator c, Owner o, Waiter w){
       this.cu = c;
       this.ow = o;
       this.wa = w;
    }
    
   
    public void run() {
        
    }
    
    public synchronized void NotifyLastCall(){
        System.out.println("IT IS ALMOST CLOSING TIME");
        
    }
    
    public synchronized void NotifyClosingTime(){
        System.out.println("CAFE IS NOW CLOSED !");
        cu.closingTime = true;
        ow.closingTime = true;
        wa.closingTime = true;
        
    }
}
