/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author jared
 */
public class Owner implements Runnable{
    String name;
    Cafe c;
    public boolean closingTime = false;
    
    public Owner(String position,Cafe cf)
    {
        this.name = position;
        this.c = cf;
    }
    
 
     public void run() {
        try {
            Thread.sleep(1000);

        } catch (InterruptedException ex) {
            Logger.getLogger(Waiter.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println("OWNER STARTED....");
        while(!closingTime){
            try {
                c.Serve(name);
            } catch (InterruptedException ex) {
                Logger.getLogger(Owner.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        if(closingTime){
            try {
                Thread.sleep(5000);
            } catch (InterruptedException ex) {
                Logger.getLogger(Owner.class.getName()).log(Level.SEVERE, null, ex);
            } 
        }

    }
}
