/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment;

/**
 *
 * @author jared
 */
public class ServingArea {
    Cupboard c; //creating cupboard

    //putting cupboard inside serving area
    public ServingArea(Cupboard c){
        this.c = c; //cupboard c passed inside serving area class
    }
    
    //using juicetap to pour juice and create drink
    public synchronized void useJuiceTap(String position) throws InterruptedException{
        System.out.println(position + " IS NOW USING JUICE TAP");
        Thread.sleep(2000);
    }
    
    //using cupboard to take ingredients or cup/glass
    public synchronized void useCupboard(String position, int order) throws InterruptedException{
        // order = 0 means its ordering juice
        if (order == 0){
            c.takeGlass(position);
            Thread.sleep(2000);
        }
        // else order = 1 means its ordering coffee
        else{
            c.takeCup(position);
            c.takeMilk(position);
            c.takeCoffee(position);
            Thread.sleep(2000);
        }
    }
}

